package primeiroLote.exer02;

import java.util.Date;

public class Transacao {
	
	private double valor;
	private Date date;

}
