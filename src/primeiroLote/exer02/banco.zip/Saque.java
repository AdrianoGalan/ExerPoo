package primeiroLote.exer02;

public class Saque extends Transacao  {

}
