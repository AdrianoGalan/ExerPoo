package primeiroLote.exer02;

public class Deposito extends Transacao {

}
