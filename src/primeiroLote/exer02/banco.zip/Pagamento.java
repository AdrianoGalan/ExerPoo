package primeiroLote.exer02;

public class Pagamento extends Transacao  {
	
	private String boleto;

}
