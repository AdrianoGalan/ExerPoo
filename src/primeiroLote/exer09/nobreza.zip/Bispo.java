package primeiroLote.exer09;

public  class Bispo extends Padre {

	@Override
	public void rezar() {
		// TODO Auto-generated method stub
		
	}

}
