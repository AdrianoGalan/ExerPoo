package primeiroLote.exer09;

public interface Diplomata {
	
	void fazerDiplomacia();

}
