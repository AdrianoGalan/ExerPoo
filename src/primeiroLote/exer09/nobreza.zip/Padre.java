package primeiroLote.exer09;

public abstract class Padre implements Fiel {

}
