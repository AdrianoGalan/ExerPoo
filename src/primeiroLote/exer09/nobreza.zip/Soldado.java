package primeiroLote.exer09;

public class Soldado {

}
