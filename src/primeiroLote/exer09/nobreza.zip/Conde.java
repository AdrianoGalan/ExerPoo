package primeiroLote.exer09;

public class Conde extends Nobre {

}
