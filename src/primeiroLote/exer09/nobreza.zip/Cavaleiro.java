package primeiroLote.exer09;

public interface Cavaleiro {
	
	void duelar();

}
