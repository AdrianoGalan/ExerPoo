package primeiroLote.exer09;

public interface Fiel {
	
	void rezar();

}
