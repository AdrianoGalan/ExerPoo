package primeiroLote.exer09;

public class Principe extends Nobre implements Cavaleiro{

	@Override
	public void duelar() {
		// TODO Auto-generated method stub
		
	}

}
