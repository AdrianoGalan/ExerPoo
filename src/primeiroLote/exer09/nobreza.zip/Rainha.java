package primeiroLote.exer09;

public class Rainha extends Nobre implements Diplomata {

	@Override
	public void fazerDiplomacia() {
		// TODO Auto-generated method stub
		
	}

}
