package primeiroLote.exer09;

public class Nobre {
	
	private Conselheiro conselheiro;
	private Soldado[] soldados;
	
	public void governar() {
		
	}
}
