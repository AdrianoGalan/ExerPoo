package primeiroLote.exer09;

public class Conselheiro {
	
	private Bispo[] bispo;

}
